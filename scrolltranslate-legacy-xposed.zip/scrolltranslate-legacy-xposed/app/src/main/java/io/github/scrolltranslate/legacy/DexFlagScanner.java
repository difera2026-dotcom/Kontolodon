package io.github.scrolltranslate.legacy;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Lightweight DEX bytecode scanner to locate obfuscated Google App feature flag accessors
 * and Live Translate action classes dynamically across Google App updates.
 */
public final class DexFlagScanner {

    public static final class FlagMethod {
        public final String tag;
        public final String className;
        public final String methodName;
        public final String dexName;

        public FlagMethod(String tag, String className, String methodName, String dexName) {
            this.tag = tag;
            this.className = className;
            this.methodName = methodName;
            this.dexName = dexName;
        }

        public String key() {
            return className + "#" + methodName;
        }

        @Override
        public String toString() {
            return tag + " -> " + className + "." + methodName + " (" + dexName + ")";
        }
    }

    public static final class ScanReport {
        public final List<FlagMethod> hits = new ArrayList<>();
        public final List<String> notes = new ArrayList<>();
    }

    // Dalvik opcode instruction lengths in 16-bit code units (index = opcode 0x00..0xFF)
    private static final int[] OPCODE_WIDTH = new int[256];
    static {
        // Default 1 unit
        for (int i = 0; i < 256; i++) OPCODE_WIDTH[i] = 1;
        // 2 code units
        int[] w2 = {
            0x02, 0x05, 0x08, 0x13, 0x15, 0x16, 0x19, 0x1a, 0x1c, 0x1f, 0x20, 0x22, 0x23,
            0x29, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
            0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d,
            0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f, 0x50, 0x51,
            0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,
            0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d,
            0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f,
            0xa0, 0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf,
            0xd0, 0xd1, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xdb, 0xdc, 0xdd, 0xde, 0xdf,
            0xe0, 0xe1, 0xe2, 0xfe, 0xff
        };
        for (int op : w2) OPCODE_WIDTH[op] = 2;

        // 3 code units
        int[] w3 = {
            0x03, 0x06, 0x09, 0x14, 0x17, 0x1b, 0x24, 0x25, 0x26, 0x2a, 0x2b, 0x2c,
            0x6e, 0x6f, 0x70, 0x71, 0x72, 0x74, 0x75, 0x76, 0x77, 0x78,
            0xfb, 0xfc, 0xfd
        };
        for (int op : w3) OPCODE_WIDTH[op] = 3;

        // 4 code units
        OPCODE_WIDTH[0xfa] = 4;
        // 5 code units (const-wide)
        OPCODE_WIDTH[0x18] = 5;
    }

    public static ScanReport scanStrings(List<File> apks, Set<String> targetStrings) {
        ScanReport report = new ScanReport();
        Set<String> seen = new HashSet<>();

        for (File apk : apks) {
            if (apk == null || !apk.isFile()) continue;
            try (ZipFile zip = new ZipFile(apk)) {
                for (String dexName : dexEntryNames(zip)) {
                    byte[] dex = readEntry(zip, zip.getEntry(dexName));
                    if (dex != null && dex.length > 112) {
                        scanDexForStrings(dex, dexName, targetStrings, seen, report);
                    }
                }
            } catch (Throwable t) {
                report.notes.add("apk_open_failed " + apk.getName() + ": " + t.getMessage());
            }
        }
        return report;
    }

    public static ScanReport findZeroArgIntMethods(List<File> apks, int targetInt) {
        ScanReport report = new ScanReport();
        Set<String> seen = new HashSet<>();

        for (File apk : apks) {
            if (apk == null || !apk.isFile()) continue;
            try (ZipFile zip = new ZipFile(apk)) {
                for (String dexName : dexEntryNames(zip)) {
                    byte[] dex = readEntry(zip, zip.getEntry(dexName));
                    if (dex != null && dex.length > 112) {
                        scanDexForZeroArgInt(dex, dexName, targetInt, seen, report);
                    }
                }
            } catch (Throwable t) {
                report.notes.add("apk_open_failed " + apk.getName() + ": " + t.getMessage());
            }
        }
        return report;
    }

    private static void scanDexForStrings(byte[] dex, String dexName, Set<String> targets,
                                          Set<String> seen, ScanReport report) {
        try {
            int strSize = i4(dex, 56);
            int strOff = i4(dex, 60);
            int typeOff = i4(dex, 68);
            int protoOff = i4(dex, 76);
            int methodOff = i4(dex, 92);
            int classSize = i4(dex, 96);
            int classOff = i4(dex, 100);

            Map<Integer, String> targetStrIdx = new HashMap<>();
            for (String s : targets) {
                int idx = findStringIndex(dex, strSize, strOff, s);
                if (idx >= 0) {
                    targetStrIdx.put(idx, s);
                }
            }
            if (targetStrIdx.isEmpty()) return;

            for (int c = 0; c < classSize; c++) {
                int cDefOff = classOff + c * 32;
                int classDataOff = i4(dex, cDefOff + 24);
                if (classDataOff <= 0) continue;

                int[] pos = {classDataOff};
                int staticFields = uleb128(dex, pos);
                int instanceFields = uleb128(dex, pos);
                int directMethods = uleb128(dex, pos);
                int virtualMethods = uleb128(dex, pos);

                for (int i = 0; i < staticFields + instanceFields; i++) {
                    uleb128(dex, pos);
                    uleb128(dex, pos);
                }

                int classIdx = i4(dex, cDefOff);
                String className = null;

                for (int group = 0; group < 2; group++) {
                    int count = (group == 0) ? directMethods : virtualMethods;
                    int methodIdx = 0;
                    for (int m = 0; m < count; m++) {
                        methodIdx += uleb128(dex, pos);
                        uleb128(dex, pos); // access flags
                        int codeOff = uleb128(dex, pos);
                        if (codeOff <= 0) continue;

                        String matchedFlag = codeContainsStringIdx(dex, codeOff, targetStrIdx);
                        if (matchedFlag != null) {
                            if (className == null) {
                                className = descriptorToClassName(typeName(dex, classIdx, typeOff, strOff));
                            }
                            String mName = methodName(dex, methodIdx, methodOff, strOff);
                            FlagMethod fm = new FlagMethod(matchedFlag, className, mName, dexName);
                            if (seen.add(fm.key() + ":" + matchedFlag)) {
                                report.hits.add(fm);
                            }
                        }
                    }
                }
            }
        } catch (Throwable t) {
            report.notes.add("dex_scan_failed " + dexName + ": " + t.getMessage());
        }
    }

    private static void scanDexForZeroArgInt(byte[] dex, String dexName, int targetInt,
                                             Set<String> seen, ScanReport report) {
        try {
            int strOff = i4(dex, 60);
            int typeOff = i4(dex, 68);
            int protoOff = i4(dex, 76);
            int methodOff = i4(dex, 92);
            int classSize = i4(dex, 96);
            int classOff = i4(dex, 100);

            for (int c = 0; c < classSize; c++) {
                int cDefOff = classOff + c * 32;
                int classDataOff = i4(dex, cDefOff + 24);
                if (classDataOff <= 0) continue;

                int[] pos = {classDataOff};
                int staticFields = uleb128(dex, pos);
                int instanceFields = uleb128(dex, pos);
                int directMethods = uleb128(dex, pos);
                int virtualMethods = uleb128(dex, pos);

                for (int i = 0; i < staticFields + instanceFields; i++) {
                    uleb128(dex, pos);
                    uleb128(dex, pos);
                }

                int classIdx = i4(dex, cDefOff);
                String className = null;

                for (int group = 0; group < 2; group++) {
                    int count = (group == 0) ? directMethods : virtualMethods;
                    int methodIdx = 0;
                    for (int m = 0; m < count; m++) {
                        methodIdx += uleb128(dex, pos);
                        uleb128(dex, pos); // access flags
                        int codeOff = uleb128(dex, pos);
                        if (codeOff <= 0) continue;

                        if (!returnsIntNoArgs(dex, methodIdx, methodOff, protoOff, typeOff, strOff)) {
                            continue;
                        }
                        if (codeContainsInt(dex, codeOff, targetInt)) {
                            if (className == null) {
                                className = descriptorToClassName(typeName(dex, classIdx, typeOff, strOff));
                            }
                            String mName = methodName(dex, methodIdx, methodOff, strOff);
                            FlagMethod fm = new FlagMethod("0x" + Integer.toHexString(targetInt), className, mName, dexName);
                            if (seen.add(fm.key())) {
                                report.hits.add(fm);
                            }
                        }
                    }
                }
            }
        } catch (Throwable t) {
            report.notes.add("dex_int_scan_failed " + dexName + ": " + t.getMessage());
        }
    }

    private static String codeContainsStringIdx(byte[] dex, int codeOff, Map<Integer, String> targets) {
        int insnsSize = i4(dex, codeOff + 12);
        int base = codeOff + 16;
        int pc = 0;
        while (pc < insnsSize) {
            int unit = u2(dex, base + pc * 2);
            int op = unit & 0xFF;
            if (op == 0x00 && unit != 0) {
                int skip = payloadSkip(dex, base, pc, unit);
                if (skip <= 0) break;
                pc += skip;
                continue;
            }
            if (op == 0x1a && pc + 1 < insnsSize) {
                int sIdx = u2(dex, base + (pc + 1) * 2);
                String match = targets.get(sIdx);
                if (match != null) return match;
            } else if (op == 0x1b && pc + 2 < insnsSize) {
                int sIdx = i4(dex, base + (pc + 1) * 2);
                String match = targets.get(sIdx);
                if (match != null) return match;
            }
            pc += OPCODE_WIDTH[op];
        }
        return null;
    }

    private static boolean codeContainsInt(byte[] dex, int codeOff, int targetInt) {
        int insnsSize = i4(dex, codeOff + 12);
        int base = codeOff + 16;
        int pc = 0;
        while (pc < insnsSize) {
            int unit = u2(dex, base + pc * 2);
            int op = unit & 0xFF;
            if (op == 0x00 && unit != 0) {
                int skip = payloadSkip(dex, base, pc, unit);
                if (skip <= 0) break;
                pc += skip;
                continue;
            }
            if (op == 0x14 && pc + 2 < insnsSize) {
                int val = i4(dex, base + (pc + 1) * 2);
                if (val == targetInt) return true;
            }
            pc += OPCODE_WIDTH[op];
        }
        return false;
    }

    private static int payloadSkip(byte[] dex, int base, int pc, int ident) {
        if (ident == 0x0100) { // packed-switch-payload
            int size = u2(dex, base + (pc + 1) * 2);
            return size * 2 + 4;
        } else if (ident == 0x0200) { // sparse-switch-payload
            int size = u2(dex, base + (pc + 1) * 2);
            return size * 4 + 2;
        } else if (ident == 0x0300) { // fill-array-data-payload
            int elemWidth = u2(dex, base + (pc + 1) * 2);
            int size = i4(dex, base + (pc + 2) * 2);
            return ((size * elemWidth + 1) / 2) + 4;
        }
        return 1;
    }

    private static boolean returnsIntNoArgs(byte[] dex, int methodIdx, int methodOff,
                                            int protoOff, int typeOff, int strOff) {
        int mOff = methodOff + methodIdx * 8;
        int protoIdx = u2(dex, mOff + 2);
        int pOff = protoOff + protoIdx * 12;
        int retTypeIdx = i4(dex, pOff + 4);
        int paramsOff = i4(dex, pOff + 8);
        if (paramsOff != 0 && i4(dex, paramsOff) != 0) return false;
        String retDesc = typeName(dex, retTypeIdx, typeOff, strOff);
        return "I".equals(retDesc);
    }

    private static int findStringIndex(byte[] dex, int strSize, int strOff, String target) {
        int lo = 0, hi = strSize - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            String s = readString(dex, mid, strOff);
            int cmp = s.compareTo(target);
            if (cmp == 0) return mid;
            if (cmp < 0) lo = mid + 1;
            else hi = mid - 1;
        }
        return -1;
    }

    private static String readString(byte[] dex, int strIdx, int strOff) {
        int dataOff = i4(dex, strOff + strIdx * 4);
        int[] pos = {dataOff};
        uleb128(dex, pos); // utf16 size
        int start = pos[0];
        int end = start;
        while (end < dex.length && dex[end] != 0) end++;
        return new String(dex, start, end - start, StandardCharsets.UTF_8);
    }

    private static String typeName(byte[] dex, int typeIdx, int typeOff, int strOff) {
        int strIdx = i4(dex, typeOff + typeIdx * 4);
        return readString(dex, strIdx, strOff);
    }

    private static String methodName(byte[] dex, int methodIdx, int methodOff, int strOff) {
        int strIdx = i4(dex, methodOff + methodIdx * 8 + 4);
        return readString(dex, strIdx, strOff);
    }

    private static String descriptorToClassName(String desc) {
        if (desc.startsWith("L") && desc.endsWith(";")) {
            return desc.substring(1, desc.length() - 1).replace('/', '.');
        }
        return desc;
    }

    private static List<String> dexEntryNames(ZipFile zip) {
        List<String> list = new ArrayList<>();
        Enumeration<? extends ZipEntry> entries = zip.entries();
        while (entries.hasMoreElements()) {
            String name = entries.nextElement().getName();
            if (name.startsWith("classes") && name.endsWith(".dex") && !name.contains("/")) {
                list.add(name);
            }
        }
        Collections.sort(list, Comparator.comparingInt(DexFlagScanner::dexOrdinal));
        return list;
    }

    private static int dexOrdinal(String name) {
        if ("classes.dex".equals(name)) return 1;
        try {
            return Integer.parseInt(name.substring(7, name.length() - 4));
        } catch (NumberFormatException e) {
            return Integer.MAX_VALUE;
        }
    }

    private static byte[] readEntry(ZipFile zip, ZipEntry entry) throws IOException {
        if (entry == null) return null;
        try (InputStream is = zip.getInputStream(entry);
             ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.max(4096, entry.getSize()))) {
            byte[] buf = new byte[16384];
            int r;
            while ((r = is.read(buf)) != -1) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }

    private static int u2(byte[] d, int o) {
        return (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8);
    }

    private static int i4(byte[] d, int o) {
        return (d[o] & 0xFF)
                | ((d[o + 1] & 0xFF) << 8)
                | ((d[o + 2] & 0xFF) << 16)
                | ((d[o + 3] & 0xFF) << 24);
    }

    private static int uleb128(byte[] d, int[] pos) {
        int res = 0, shift = 0;
        int p = pos[0];
        while (true) {
            int b = d[p++] & 0xFF;
            res |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) break;
            shift += 7;
        }
        pos[0] = p;
        return res;
    }
}
