package io.github.scrolltranslate.legacy;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.SurfaceControl;
import android.view.ViewGroup;
import android.view.WindowManager;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Legacy Xposed API 82 port of ScrollTranslate.
 * Compatible with all LSPosed builds (v1.9.2, v1.9.3, LSPosed_mod, JingMatrix, ReLSPosed).
 */
public final class ScrollTranslateModule implements IXposedHookLoadPackage {

    private static final String TAG = "[ScrollTranslateLegacy] ";
    private static final String TARGET_PACKAGE = "com.google.android.googlequicksearchbox";
    private static final String LENS_PROCESS = "com.google.android.googlequicksearchbox:googleapp";
    private static final String SYSTEMUI_PACKAGE = "com.android.systemui";
    private static final String ANDROID_PACKAGE = "android";

    private static final String LIVE_TRANSLATE_SYSTEM_FEATURE =
            "com.google.android.feature.CONTEXTUAL_SEARCH_LIVE_TRANSLATE";

    private static final Set<String> LIVE_TRANSLATE_FLAG_IDS = new HashSet<>(Arrays.asList(
            "45716363",
            "45724135",
            "45785436"
    ));

    private static final int TYPE_APPLICATION_OVERLAY = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    private static final int FLAG_SECURE_VALUE = WindowManager.LayoutParams.FLAG_SECURE;

    private final AtomicBoolean featureHooksDone = new AtomicBoolean(false);
    private final AtomicBoolean flagHooksDone = new AtomicBoolean(false);
    private final AtomicBoolean actionHooksDone = new AtomicBoolean(false);
    private final AtomicBoolean consentHooksDone = new AtomicBoolean(false);
    private final AtomicBoolean overlayHooksDone = new AtomicBoolean(false);
    private final AtomicBoolean sysHooksDone = new AtomicBoolean(false);

    private volatile int cachedGsaUid = -1;

    private static void log(String msg) {
        XposedBridge.log(TAG + msg);
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        String pkg = lpparam.packageName;
        String proc = lpparam.processName;

        if (ANDROID_PACKAGE.equals(pkg) && ANDROID_PACKAGE.equals(proc)) {
            log("event=package_ready package=android");
            installSystemServerHooks(lpparam.classLoader);
            return;
        }

        if (SYSTEMUI_PACKAGE.equals(pkg)) {
            log("event=package_ready package=" + pkg);
            installProjectionConsentHook(lpparam.classLoader, proc);
            return;
        }

        if (TARGET_PACKAGE.equals(pkg)) {
            log("event=package_ready package=" + pkg + " process=" + proc);
            installSystemFeatureHooks(lpparam.classLoader);
            installProjectionConsentHook(lpparam.classLoader, proc);
            installOverlaySecureHooks(lpparam.classLoader);

            if (isLensCapableProcess(proc)) {
                installFlagHooks(lpparam);
                installAppContextHook(lpparam.classLoader);
            } else {
                log("event=flag_scan_skipped reason=process_out_of_scope process=" + proc);
            }
        }
    }

    private boolean isLensCapableProcess(String processName) {
        return TARGET_PACKAGE.equals(processName) || LENS_PROCESS.equals(processName);
    }

    // 1. Spoof CONTEXTUAL_SEARCH_LIVE_TRANSLATE system feature
    private void installSystemFeatureHooks(ClassLoader cl) {
        if (!featureHooksDone.compareAndSet(false, true)) return;

        Class<?> apm = XposedHelpers.findClassIfExists("android.app.ApplicationPackageManager", cl);
        if (apm != null) {
            hookFeatureMethods(apm);
        }
        Class<?> pm = XposedHelpers.findClassIfExists("android.content.pm.PackageManager", cl);
        if (pm != null) {
            hookFeatureMethods(pm);
        }
    }

    private void hookFeatureMethods(Class<?> clazz) {
        for (Method m : clazz.getDeclaredMethods()) {
            if (!"hasSystemFeature".equals(m.getName())) continue;
            if (Modifier.isAbstract(m.getModifiers())) continue;
            Class<?>[] params = m.getParameterTypes();
            if (params.length < 1 || params[0] != String.class) continue;
            try {
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (LIVE_TRANSLATE_SYSTEM_FEATURE.equals(param.args[0])) {
                            param.setResult(Boolean.TRUE);
                        }
                    }
                });
                log("event=hook_installed target=" + clazz.getSimpleName() + ".hasSystemFeature(" + params.length + ")");
            } catch (Throwable t) {
                log("event=feature_method_hook_failed method=" + m + " err=" + t);
            }
        }
    }

    // 2. Dynamically scan Google App DEX for Live Translate flag accessors and force true
    private void installFlagHooks(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!flagHooksDone.compareAndSet(false, true)) return;

        long start = System.currentTimeMillis();
        List<File> apks = listApks(lpparam.appInfo);
        DexFlagScanner.ScanReport report = DexFlagScanner.scanStrings(apks, LIVE_TRANSLATE_FLAG_IDS);
        log("event=flag_scan_done apks=" + apks.size() + " hits=" + report.hits.size()
                + " ms=" + (System.currentTimeMillis() - start));

        for (String note : report.notes) {
            log("event=flag_scan_note " + note);
        }

        for (DexFlagScanner.FlagMethod fm : report.hits) {
            hookFlagAccessor(lpparam.classLoader, fm);
        }
    }

    private void hookFlagAccessor(ClassLoader cl, DexFlagScanner.FlagMethod fm) {
        try {
            Class<?> target = XposedHelpers.findClassIfExists(fm.className, cl);
            if (target == null) return;
            for (Method m : target.getDeclaredMethods()) {
                if (!m.getName().equals(fm.methodName)) continue;
                Class<?> ret = m.getReturnType();
                if (ret == boolean.class || ret == Boolean.class) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            param.setResult(Boolean.TRUE);
                        }
                    });
                    log("event=hook_installed target=" + fm);
                }
            }
        } catch (Throwable t) {
            log("event=flag_hook_failed target=" + fm + " err=" + t);
        }
    }

    // 3. Hook Application.onCreate to find & force Live Translate Lens action visibility
    private void installAppContextHook(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Context ctx = (Context) param.thisObject;
                    if (ctx != null && TARGET_PACKAGE.equals(ctx.getPackageName())) {
                        installLiveTranslateActionHook(ctx);
                    }
                }
            });
            log("event=hook_installed target=android.app.Application.onCreate");
        } catch (Throwable t) {
            log("event=app_context_hook_failed err=" + t);
        }
    }

    private void installLiveTranslateActionHook(Context ctx) {
        if (!actionHooksDone.compareAndSet(false, true)) return;
        try {
            int labelId = ctx.getResources().getIdentifier(
                    "lens_live_translate_action_text", "string", TARGET_PACKAGE);
            log("event=action_label_id id=0x" + Integer.toHexString(labelId));
            if (labelId == 0) return;

            List<File> apks = listApks(ctx.getApplicationInfo());
            DexFlagScanner.ScanReport report = DexFlagScanner.findZeroArgIntMethods(apks, labelId);
            log("event=action_scan_done candidates=" + report.hits.size());

            ClassLoader cl = ctx.getClassLoader();
            for (DexFlagScanner.FlagMethod fm : report.hits) {
                hookActionVisibility(cl, fm);
            }
        } catch (Throwable t) {
            log("event=action_hook_install_failed err=" + t);
        }
    }

    private void hookActionVisibility(ClassLoader cl, DexFlagScanner.FlagMethod fm) {
        try {
            Class<?> clazz = XposedHelpers.findClassIfExists(fm.className, cl);
            if (clazz == null) {
                log("event=action_class_load_failed target=" + fm.className);
                return;
            }

            // Force boolean cache fields after constructor
            XposedBridge.hookAllConstructors(clazz, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    forceBooleanFields(param.thisObject, clazz.getName());
                }
            });

            // Hook visibility/availability boolean methods (0-arg boolean returning)
            for (Method m : clazz.getDeclaredMethods()) {
                if (m.getParameterCount() == 0 && (m.getReturnType() == boolean.class || m.getReturnType() == Boolean.class)) {
                    String name = m.getName();
                    if ("i".equals(name) || "a".equals(name)) {
                        XposedBridge.hookMethod(m, new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) {
                                param.setResult(Boolean.TRUE);
                            }
                        });
                        log("event=action_visibility class=" + clazz.getName() + " method=" + name);
                    }
                }
            }
        } catch (Throwable t) {
            log("event=action_visibility_hook_failed target=" + fm.className + " err=" + t);
        }
    }

    private void forceBooleanFields(Object instance, String className) {
        if (instance == null) return;
        try {
            Class<?> c = instance.getClass();
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    if (Modifier.isStatic(f.getModifiers())) continue;
                    if (f.getType() == boolean.class) {
                        f.setAccessible(true);
                        if (!f.getBoolean(instance)) {
                            f.setBoolean(instance, true);
                        }
                    }
                }
                c = c.getSuperclass();
            }
        } catch (Throwable t) {
            log("event=action_cache_force_failed target=" + className + " err=" + t);
        }
    }

    // 4. Silently grant MediaProjection permission for Google App
    private void installProjectionConsentHook(ClassLoader cl, String processName) {
        if (!consentHooksDone.compareAndSet(false, true)) return;
        try {
            Class<?> proxy = XposedHelpers.findClassIfExists(
                    "android.media.projection.IMediaProjectionManager$Stub$Proxy", cl);
            if (proxy == null) return;

            XposedBridge.hookAllMethods(proxy, "hasProjectionPermission", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args != null) {
                        for (Object arg : param.args) {
                            if (TARGET_PACKAGE.equals(arg)) {
                                param.setResult(Boolean.TRUE);
                                return;
                            }
                        }
                    }
                }
            });
            log("event=hook_installed target=IMediaProjectionManager.Stub.Proxy.hasProjectionPermission process=" + processName);
        } catch (Throwable t) {
            log("event=consent_hook_failed err=" + t);
        }
    }

    // 5. Mark Google App overlay windows with FLAG_SECURE
    private void installOverlaySecureHooks(ClassLoader cl) {
        if (!overlayHooksDone.compareAndSet(false, true)) return;
        try {
            Class<?> wmg = XposedHelpers.findClassIfExists("android.view.WindowManagerGlobal", cl);
            if (wmg == null) return;

            XC_MethodHook secureHook = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args == null) return;
                    for (Object arg : param.args) {
                        if (arg instanceof WindowManager.LayoutParams) {
                            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) arg;
                            if (lp.type == TYPE_APPLICATION_OVERLAY && (lp.flags & FLAG_SECURE_VALUE) == 0) {
                                lp.flags |= FLAG_SECURE_VALUE;
                            }
                        } else if (arg instanceof ViewGroup.LayoutParams) {
                            // Ignore non-WindowManager layout params
                        }
                    }
                }
            };

            int count = 0;
            count += XposedBridge.hookAllMethods(wmg, "addView", secureHook).size();
            count += XposedBridge.hookAllMethods(wmg, "updateViewLayout", secureHook).size();
            log("event=overlay_secure_hooks_installed count=" + count);
        } catch (Throwable t) {
            log("event=overlay_secure_hook_failed err=" + t);
        }
    }

    // 6. System Server hooks: unclamp overlay alpha & skip screenshot on Google overlay
    private void installSystemServerHooks(ClassLoader cl) {
        if (!sysHooksDone.compareAndSet(false, true)) return;

        int alphaCount = installOverlayAlphaHooks(cl);
        int skipCount = installSkipScreenshotHooks(cl);
        log("event=ss_hooks_installed count=" + (alphaCount + skipCount));
    }

    private int installOverlayAlphaHooks(ClassLoader cl) {
        try {
            Class<?> displayPolicy = XposedHelpers.findClassIfExists(
                    "com.android.server.wm.DisplayPolicy", cl);
            if (displayPolicy == null) return 0;

            Set<XC_MethodHook.Unhook> hooks = XposedBridge.hookAllMethods(
                    displayPolicy, "adjustWindowParamsLw", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                unclampOverlayAlpha(param.thisObject, param.args);
                            } catch (Throwable ignored) {}
                        }
                    });
            log("event=ss_alpha_hooks_installed count=" + hooks.size());
            return hooks.size();
        } catch (Throwable t) {
            log("event=ss_alpha_hook_failed err=" + t);
            return 0;
        }
    }

    private void unclampOverlayAlpha(Object displayPolicy, Object[] args) {
        if (args == null || args.length < 2) return;
        Object win = args[0];
        Object attrsObj = args[1];
        if (!(attrsObj instanceof WindowManager.LayoutParams)) return;
        WindowManager.LayoutParams attrs = (WindowManager.LayoutParams) attrsObj;
        if (attrs.type != TYPE_APPLICATION_OVERLAY) return;

        int uid = resolveGsaUid(displayPolicy);
        if (uid <= 0) return;

        int winUid = getWindowUid(win);
        if (winUid != uid) return;

        if (attrs.alpha < 1.0f) {
            attrs.alpha = 1.0f;
            log("event=ss_overlay_alpha_fix alpha=1.0");
        }
    }

    private int installSkipScreenshotHooks(ClassLoader cl) {
        try {
            Class<?> wsa = XposedHelpers.findClassIfExists(
                    "com.android.server.wm.WindowStateAnimator", cl);
            if (wsa == null) return 0;

            Set<XC_MethodHook.Unhook> hooks = XposedBridge.hookAllMethods(
                    wsa, "createSurfaceLocked", new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                skipScreenshotForOverlay(param.thisObject);
                            } catch (Throwable ignored) {}
                        }
                    });
            log("event=ss_skip_screenshot_installed count=" + hooks.size());
            return hooks.size();
        } catch (Throwable t) {
            log("event=ss_skip_screenshot_hook_failed err=" + t);
            return 0;
        }
    }

    private void skipScreenshotForOverlay(Object animator) {
        Object win = getFieldSafe(animator, "mWin");
        if (win == null) return;

        Object attrsObj = getFieldSafe(win, "mAttrs");
        if (!(attrsObj instanceof WindowManager.LayoutParams)) return;
        WindowManager.LayoutParams attrs = (WindowManager.LayoutParams) attrsObj;
        if (attrs.type != TYPE_APPLICATION_OVERLAY) return;
        if ((attrs.flags & FLAG_SECURE_VALUE) == 0) return;

        int gsaUid = resolveGsaUid(animator);
        if (gsaUid <= 0) return;
        if (getWindowUid(win) != gsaUid) return;

        Object sc = getFieldSafe(animator, "mSurfaceControl");
        if (sc == null) {
            Object winSc = getFieldSafe(win, "mSurfaceControl");
            if (winSc != null) sc = winSc;
        }
        if (!(sc instanceof SurfaceControl)) return;

        try {
            SurfaceControl.Transaction tx = new SurfaceControl.Transaction();
            try {
                Method setSkip = SurfaceControl.Transaction.class.getMethod(
                        "setSkipScreenshot", SurfaceControl.class, boolean.class);
                setSkip.invoke(tx, sc, true);
            } catch (NoSuchMethodException ignored) {}
            try {
                Method setTrusted = SurfaceControl.Transaction.class.getMethod(
                        "setTrustedOverlay", SurfaceControl.class, boolean.class);
                setTrusted.invoke(tx, sc, true);
            } catch (NoSuchMethodException ignored) {}
            tx.apply();
            tx.close();
            log("event=ss_overlay_skip_screenshot title=" + attrs.getTitle());
        } catch (Throwable t) {
            log("event=ss_skip_screenshot_failed err=" + t);
        }
    }

    private int resolveGsaUid(Object holder) {
        if (cachedGsaUid > 0) return cachedGsaUid;
        try {
            Context ctx = (Context) getFieldSafe(holder, "mContext");
            if (ctx == null) {
                Object service = getFieldSafe(holder, "mService");
                if (service != null) {
                    ctx = (Context) getFieldSafe(service, "mContext");
                }
            }
            if (ctx != null) {
                PackageManager pm = ctx.getPackageManager();
                if (pm != null) {
                    ApplicationInfo ai = pm.getApplicationInfo(TARGET_PACKAGE, 0);
                    cachedGsaUid = ai.uid;
                    return cachedGsaUid;
                }
            }
        } catch (Throwable ignored) {}
        return -1;
    }

    private int getWindowUid(Object win) {
        Object session = getFieldSafe(win, "mSession");
        if (session != null) {
            Object uidObj = getFieldSafe(session, "mUid");
            if (uidObj instanceof Number) {
                return ((Number) uidObj).intValue();
            }
        }
        return -1;
    }

    private static Object getFieldSafe(Object obj, String name) {
        if (obj == null) return null;
        Class<?> c = obj.getClass();
        while (c != null && c != Object.class) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(obj);
            } catch (NoSuchFieldException e) {
                c = c.getSuperclass();
            } catch (Throwable t) {
                return null;
            }
        }
        return null;
    }

    private static List<File> listApks(ApplicationInfo info) {
        List<File> list = new ArrayList<>();
        if (info == null) return list;
        if (info.sourceDir != null) list.add(new File(info.sourceDir));
        if (info.splitSourceDirs != null) {
            for (String s : info.splitSourceDirs) {
                if (s != null) list.add(new File(s));
            }
        }
        return list;
    }
}
