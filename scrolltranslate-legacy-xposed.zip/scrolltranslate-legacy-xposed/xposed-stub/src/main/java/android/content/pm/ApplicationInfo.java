package android.content.pm;

public class ApplicationInfo {
    public String sourceDir;
    public String[] splitSourceDirs;
    public int uid;
}
