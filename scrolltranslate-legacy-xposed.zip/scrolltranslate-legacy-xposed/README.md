# ScrollTranslate Legacy (LSPosed API 82+)

Porting modul LSPosed **Scroll & Translate (Google Live Translate)** dari Modern libxposed API 102 ke **Classic Xposed API 82**, sehingga kompatibel dengan semua versi LSPosed (v1.9.2, v1.9.3, LSPosed_mod, JingMatrix, ReLSPosed).

## Cara Build APK Tanpa PC (via GitHub Actions)
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder ini ke repository tersebut (pastikan folder `.github/workflows/build.yml` ikut terupload).
3. Buka tab **Actions** di GitHub -> klik workflow **Build ScrollTranslate Legacy APK** -> klik **Run workflow**.
4. Tunggu ~1-2 menit, lalu download file APK di bagian **Artifacts** (`ScrollTranslate-Legacy-API82-APK`).

## Cara Build di PC (Android Studio)
1. Extract ZIP ini lalu buka folder di Android Studio.
2. Tunggu Gradle sync selesai.
3. Klik **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.

## Cara Pemasangan di LSPosed
1. Install APK hasil build.
2. Buka **LSPosed Manager -> Modules -> ScrollTranslate (Legacy API 82)**.
3. Aktifkan modul dan pastikan 3 scope berikut tercentang:
   - **System Framework** (`android`)
   - **System UI** (`com.android.systemui`)
   - **Google** (`com.google.android.googlequicksearchbox`)
4. **Reboot HP**.
5. Cek tab **Logs** di LSPosed Manager dan cari baris `[ScrollTranslateLegacy]` untuk memastikan semua hook terpasang.
